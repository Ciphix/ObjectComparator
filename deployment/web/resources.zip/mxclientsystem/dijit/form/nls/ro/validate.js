//>>built
define("dijit/form/nls/ro/validate",({invalidMessage:"Valoarea introdusă nu este validă.",missingMessage:"Această valoare este necesară.",rangeMessage:"Această valoare este în afara intervalului. "}));
